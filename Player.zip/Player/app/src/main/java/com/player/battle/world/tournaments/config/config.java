package com.player.battle.world.tournaments.config;

public class config {

    public static final String main = "http://www.battleworld.in";
//    public static String mainurl = "http://www.battleworld.in/play/";
    public static final String mainurl = "http://www.battleworld.in/battleworld/";
    public static final String mainimg = mainurl + "matchimg/";
    public static final String howtojoin = "http://www.battleworld.in/?page_id=444";
    public static final String privacypolicy = "http://www.battleworld.in/?page_id=3";
    public static final String paytmchecksum = mainurl + "paytm/";

    public static final String youtubechannel = "https://www.youtube.com/channel/UCOWD8flod9swGrdGl3i7M2g";

    // Paytm
    // Test API Details
//    public static String MID = "EJHiMn10015192456115";
//    public static String WEBSITE = "WEBSTAGING";
//    public static String INDUSTRY_TYPE_ID = "Retail";
//    public static String CALLBACK_URL = "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=";

    // Production
    public static final String MID = "cHQrqq17392877779909";
    public static final String WEBSITE = "DEFAULT";
    public static final String INDUSTRY_TYPE_ID = "Retail";
    public static final String CALLBACK_URL = "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID=";

}
